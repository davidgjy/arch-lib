+++
icon = "<b>3. </b>"
date = "2016-12-12T16:06:17+08:00"
title = "设计"
weight = 1
prev = "/02-guide/dump/"
next = "/03-design/module/"
chapter = true

+++

# 本章导航

 - 想了解架构设计及项目模块设计的概念，请阅读[实现原理](/03-design/theory/)及[目录结构说明](/03-design/module/)。
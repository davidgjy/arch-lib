+++
toc = true
date = "2016-12-06T22:38:50+08:00"
title = "目录结构说明"
weight = 2
prev = "/03-design/index/"
next = "/03-design/theory/"
+++

## elastic-job-core

elastic-job核心模块，只通过Quartz和Curator就可执行分布式作业。

## elastic-job-api

elastic-job生命周期操作的API，可独立使用。

## elastic-job-spring

elastic-job对spring支持的模块，包括命名空间，依赖注入，占位符等。

## elastic-job-console

elastic-job web控制台，可将编译之后的war放入tomcat等servlet容器中使用。

## elastic-job-example

使用示例。

## elastic-job-doc

使用markdown生成文档的项目，使用方无需关注。

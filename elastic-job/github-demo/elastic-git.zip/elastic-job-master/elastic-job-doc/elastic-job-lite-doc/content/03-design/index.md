+++
icon = "<b>3. </b>"
date = "2016-12-12T16:06:17+08:00"
title = "设计规划"
weight = 0
prev = "/02-guide/customized-hook/"
next = "/03-design/module/"
chapter = true

+++

# 本章导航

 - 想了解架构设计及项目模块设计的概念，请阅读[实现原理](/03-design/lite-design/)及[目录结构说明](/03-design/module/)。
 - Elastic-Job未来规划有哪些呢？请阅读[未来规划](/03-design/roadmap/)。
$(function() {
    validate();
    submitConfirm("post", $("#data-add-app"));
});
